$(document).ready(function() {
    $('.animation').addClass('has-animation')
})